const express=require("express");
const multer=require("multer");
const path=require("path"); //for adding file extension
const app=express();
var port=process.env.PORT||3000;

app.get("/",function(req,res){
  res.sendFile(__dirname+"/index.html");
});

var storage=multer.diskStorage({
  destination:function(req,file,callback){
    callback(null,"./uploads"); //here "." before "/uploads" is most important
  },
  filename:function(req,file,callback){
    callback(null,file.fieldname+"-"+Date.now()+path.extname(file.originalname));
  }
});

var upload=multer({storage:storage});
  
app.post("/uploadfile",upload.single("mhs"),function(req,res){
  var x=req.file.filename;
  console.log("filename: "+x);
  res.end("filename : "+x);
});

app.listen(port,function(){
  console.log("server listening port %s",port);
});
