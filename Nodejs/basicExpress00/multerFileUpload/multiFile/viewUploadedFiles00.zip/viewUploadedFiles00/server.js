var express=require("express");
var multer=require("multer");
var path=require("path");
var app=express();
app.use(express.static("./uploads"));

var port=process.env.PORT||3000;
var storage=multer.diskStorage({
  destination:function(req,file,callback){
    callback(null,"./uploads");
  },
  filename:function(req,file,callback){
    callback(null,file.fieldname+"-"+Date.now()+path.extname(file.originalname));
  }
});

var upload=multer({storage:storage});

app.get("/",(req,res)=>{
  res.sendFile(__dirname+"/index.html");
});

app.post("/uploadfile",upload.array("mhs"),(req,res)=>{
  var totalFiles=req.files.length;
  let txt="";
  for ( var i=0;i<totalFiles;i++){
     var x=req.files[i].filename;
    txt+=`<img style="width:90vmin;margin:7px;float:left;" src="${x}">`;
  }

//setTimeout(function() {
  res.format({
    "text/html":function(){
      res.send(txt);
    }
  });
  console.log(txt);
  

  //res.set({"Content-Type","text/htmm"});
  res.end();
//},3000);

});

app.listen(port,()=>console.log("server listening at port %s",port));



