whatever you name a file and how many you upload a file, you can get them using req.files object

here,you can upload multuple files,long press to select multiple files. after uploading them, pictures will be visible at route(/uploads)


