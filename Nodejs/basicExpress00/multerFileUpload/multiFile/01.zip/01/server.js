var express=require("express");
var multer=require("multer");
var path=require("path");
var app=express();
var port=process.env.PORT||3000;

var storage=multer.diskStorage({
  destination:function(req,file,callback){
    callback(null,"./uploads");
  },
  filename:function(req,file,callback){
    callback(null,file.fieldname+Date.now()+path.extname(file.originalname));
  }
});

var upload=multer({storage:storage});

app.get("/",function(req,res){
  res.sendFile(__dirname+"/index.html");
});

app.post("/uploadfile",upload.array("mhs"),function(req,res){
  res.send("Total files : "+req.files.length);
  res.end();
});

app.listen(port,()=>console.log("server is listening at port %s",port));