var express=require("express");
var multer=require("multer");
var path=require("path");
var app=express();
var port=process.env.PORT||3000;

var storage=multer.diskStorage({
  destination:function(req,file,callback){
    callback(null,"./uploads");
  },
  filename:function(req,file,callback){
    callback(null,file.fieldname+"-"+Date.now()+path.extname(file.originalname));
  }
});

var upload=multer({storage:storage});

app.get("/",(req,res)=>{
  res.sendFile(__dirname+"/index.html");
});

app.post("/uploadfile",upload.array("mhs"),(req,res)=>{
  var totalFiles=req.files.length;
  let txt="";
  for ( var i=0;i<totalFiles;i++){
    txt+="FileNumber:"+i+"; path:"+req.files[i].path+"; filename : "+req.files[i].filename+"\n";
  }
  res.send(txt);
  res.end();
});

app.listen(port,()=>console.log("server listening at port %s",port));

/*OUTPUT

FileNumber:0; path:uploads/mhs-1640703817704.jpg; filename : mhs-1640703817704.jpg FileNumber:1; path:uploads/mhs-1640703817715.png; filename : mhs-1640703817715.png FileNumber:2; path:uploads/mhs-1640703817748.png; filename : mhs-1640703817748.png FileNumber:3; path:uploads/mhs-1640703817785.png; filename : mhs-1640703817785.png FileNumber:4; path:uploads/mhs-1640703817827.png; filename : mhs-1640703817827.png

*/

